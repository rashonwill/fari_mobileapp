import * as React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Image,
  Modal,
  TouchableHighlight,
  Dimensions,
  Animated,
  TouchableOpacity,
  Pressable,
  Alert,
  TextInput,
} from 'react-native';
import {
  BottomSheet,
  Button,
  ButtonGroup,
  withTheme,
} from 'react-native-elements';
import { NavigationContainer, DefaultTheme } from '@react-navigation/native';
import { createDrawerNavigator } from '@react-navigation/drawer';
import { useState, useEffect } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

import Swipeable from 'react-native-gesture-handler/Swipeable';
import GestureRecognizer from 'react-native-swipe-gestures';

import {
  Teko_300Light,
  Teko_400Regular,
  Teko_500Medium,
  Teko_600SemiBold,
  Teko_700Bold,
} from '@expo-google-fonts/teko';

import { FontAwesome } from '@expo/vector-icons';
import { MaterialIcons } from '@expo/vector-icons';

function Conversations() {
  const [userconversations, setUserConversations] = useState({});
  const [viewConvo, setViewConvo] = useState(false);
  const [messages, setMessages] = useState({});
  const [myInits, setMyInits] = useState({});
  const [otherInits, setOtherInits] = useState({});
  const [newMessage, setNewMessage] = useState('');
  const [myMessage, setMyMessage] = useState({});
  const [theyMessage, setTheyMessage] = useState({});

  useEffect(() => {
    const getUser = async () => {
      const loggedInUser = await AsyncStorage.getItem('fariToken');
      if (!loggedInUser) {
        Alert.alert('Sign in to view your messages');
      }
      if (loggedInUser) {
        return;
      }
    };

    const fetchConversations = async () => {
      let USER_TOKEN = await AsyncStorage.getItem('fariToken');
      let TOKEN = JSON.parse(USER_TOKEN);
      let userid = await AsyncStorage.getItem('userID');
      const response = await fetch(
        `https://fari-testapi.herokuapp.com/api/chat/myconversations/${userid}`,
        {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${TOKEN}`,
          },
        }
      );
      let data = await response.json();
      setUserConversations(data.conversation);
      return data.conversation;
    };

    async function splitConversations(conversation) {
      let myInitiations = await AsyncStorage.getItem('userID');
      let myID = JSON.parse(myInitiations);

      let meFirst = [];
      let meSecond = [];

      for (let index = 0; index < conversation.length; index++) {
        if (conversation[index].user1 === myID) {
          meFirst.push(conversation[index]);
          setMyInits(meFirst);
      
        } else {
          meSecond.push(conversation[index]);
          setOtherInits(meSecond);
        }
      }
    }

    getUser().then(fetchConversations).then(splitConversations);
  }, []);

  async function conversationMessages() {
    let conversationid = await AsyncStorage.getItem('conversationID');
    let USER_TOKEN = await AsyncStorage.getItem('fariToken');
    let TOKEN = JSON.parse(USER_TOKEN);
    try {
      const response = await fetch(
        `https://fari-testapi.herokuapp.com/api/chat/myconversations/messages/${conversationid}`,
        {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${TOKEN}`,
          },
        }
      );
      const data = await response.json();
      setMessages(data.conversation);
      return data.conversation;
    } catch (error) {
      console.log(
        'Oops Something Went Wrong! Could not get conversation messages.',
        error
      );
    }
  }

  async function renderConvoMessages(messages) {
    let meMessages = [];
    let theirMessages = [];
    let mySentMessages = await AsyncStorage.getItem('userID');

    for (let index = 0; index < messages.length; index++) {
      if (messages[index].senderid == mySentMessages) {
        meMessages.push(messages[index]);
        setMyMessage(meMessages);
      } else {
        theirMessages.push(messages[index]);
        setTheyMessage(theirMessages);
      }
    }

  }

  const rightSwipe = (progress, dragX) => {
    const scale = dragX.interpolate({
      inputRange: [0, 100],
      outputRange: [0, 1],
      extrapolate: 'clamp',
    });
    return (
      <TouchableOpacity activeOpacity={0.6}>
        <View style={styles.deleteBox}>
          <Pressable>
            <FontAwesome name="trash-o" size={24} color="black" />
          </Pressable>
        </View>
      </TouchableOpacity>
    );
  };

  
  return (
    <>
      <GestureRecognizer onSwipeDown={(viewConvo) => setViewConvo(false)}>
        <Modal
          animationType="slide"
          visible={viewConvo}
          transparent={false}
          presentationStyle={'fullScreen'}
          onRequestClose={() => {
            setViewConvo(!viewConvo);
          }}>
          <>
            <View
              style={{
                backgroundColor: '#171717',
                width: '100%',
                height: '100%',
                padding: 10,
              }}>
              <View
                style={{
                  display: 'flex',
                  flexDirection: 'column',
                  marginTop: 80,
                }}>
                {myMessage && myMessage.length > 0
                  ? myMessage.map((conversation) => {
                      return (
                        <View
                          className="message-row mine"
                          style={{
                            display: 'flex',
                            flexDirection: 'column',
                            justifyContent: 'flex-end',
                            alignItems: 'flex-end',
                          }}>
                          <Text
                            className="message-text"
                            style={{
                              color: '#fdfbf9',
                              backgroundColor: '#0c1559',
                              fontSize: 18,
                              borderRadius: 5,
                              fontFamily: 'Teko_700Bold',
                              padding: 5,
                            }}>
                            {conversation.chat_message}
                          </Text>
                          <Text
                            className="message-time"
                            style={{
                              color: '#a9a9b0',
                              fontSize: 12,
                              fontFamily: 'Teko_700Bold',
                            }}>
                            {conversation.message_date}
                          </Text>
                        </View>
                      );
                    })
                  : null}

                {theyMessage && theyMessage.length > 0
                  ? theyMessage.map((conversation) => {
                      return (
                        <View
                          className="message-row bot-message"
                          style={{
                            display: 'flex',
                            flexDirection: 'column',
                            justifyContent: 'flex-start',
                            alignItems: 'flex-start',
                          }}>
                          <Text
                            className="message-text"
                            style={{
                              color: '#fdfbf9',
                              backgroundColor: 'black',
                              opacity: '.8',
                              fontSize: 18,
                              borderRadius: 5,
                              fontFamily: 'Teko_700Bold',
                              padding: 5,
                            }}>
                            {conversation.chat_message}
                          </Text>
                          <Text
                            className="message-time"
                            style={{
                              color: '#a9a9b0',
                              fontSize: 12,
                              fontFamily: 'Teko_700Bold',
                            }}>
                            {conversation.message_date}
                          </Text>
                        </View>
                      );
                    })
                  : null}
              </View>
              <View
                style={{
                  margin: 10,
                  position: 'absolute',
                  bottom: 0,
                  width: '100%',
                }}>
                <TextInput
                  placeholder="Message"
                  style={{
                    height: 50,
                    width: '98%',
                    fontSize: 18,
                    padding: 5,
                    borderBottomColor: '#a9a9b0',
                    borderTopColor: '#a9a9b0',
                    borderWidth: 2,
                  }}
                  onChangeText={(value) => setNewMessage(value)}
                />
              </View>
            </View>
          </>
        </Modal>
      </GestureRecognizer>

      <View style={styles.chats}>
        <ScrollView>
          {userconversations && userconversations.length === 0 && (
            <Text style={styles.message}>No Chat Messages.</Text>
          )}

          {myInits && myInits.length > 0
            ? myInits.map((conversation) => {
                return (
                  <Swipeable renderRightActions={rightSwipe}>
                    <Pressable
                      style={{ width: '100%' }}
                      onPress={() => {
                        AsyncStorage.setItem(
                          'conversationID',
                          JSON.stringify(conversation.conversationid)
                        );
                        conversationMessages().then(renderConvoMessages);
                        setViewConvo(true);
                      }}>
                      <View style={styles.userConvos} key={conversation.id}>
                        <View style={styles.convoImage}>
                          <Image
                            source={{
                              uri: conversation.user2_pic,
                            }}
                            style={{
                              width: '100%',
                              height: '100%',
                              borderRadius: '50%',
                            }}
                          />
                        </View>
                        <View className="title-text">
                          <Text style={styles.titleText}>
                            {conversation.user2_username}
                          </Text>
                        </View>
                      </View>
                    </Pressable>
                  </Swipeable>
                );
              })
            : null}

          {otherInits && otherInits.length > 0
            ? otherInits.map((conversation) => {
                return (
                  <Swipeable renderRightActions={rightSwipe}>
                    <Pressable
                      style={{ width: '100%' }}
                      onPress={() => {
                        AsyncStorage.setItem(
                          'conversationID',
                          JSON.stringify(conversation.conversationid)
                        );
                        conversationMessages().then(renderConvoMessages);
                        setViewConvo(true);
                      }}>
                      <View style={styles.userConvos} key={conversation.id}>
                        <View style={styles.convoImage}>
                          <Image
                            source={{
                              uri: conversation.user1_pic,
                            }}
                            style={{
                              width: '100%',
                              height: '100%',
                              borderRadius: '50%',
                            }}
                          />
                        </View>
                        <View className="title-text">
                          <Text style={styles.titleText}>
                            {conversation.user1_username}
                          </Text>
                        </View>
                      </View>
                    </Pressable>
                  </Swipeable>
                );
              })
            : null}
        </ScrollView>
      </View>
    </>
  );
}

function Search() {
  const [allUsers, setAllUsers] = useState();

  useEffect(() => {
    const fetchUsers = async () => {
      let USER_TOKEN = await AsyncStorage.getItem('fariToken');
      let TOKEN = JSON.parse(USER_TOKEN);
      const response = await fetch(
        `https://fari-testapi.herokuapp.com/api/users/usernames`,
        {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${TOKEN}`,
          },
        }
      );
      let data = await response.json();
      setAllUsers(data.users);
      return data.users;
    };

    fetchUsers();
  }, []);

  return (
    <ScrollView>
      {allUsers && allUsers.length > 0
        ? allUsers.map((users) => {
            return (
              <View style={styles.userSearch}>
                <View style={styles.userlist}>
                  <View style={styles.userSearched}>
                    <View style={styles.userPic}>
                      <Image
                        source={{ uri: users.profile_avatar }}
                        style={{
                          width: '100%',
                          height: '100%',
                          borderRadius: '50%',
                        }}
                      />
                    </View>
                    <Text style={styles.userName}>{users.username}</Text>
                    <Button
                      buttonStyle={styles.messageMe}
                      title="Message"></Button>
                  </View>
                </View>
              </View>
            );
          })
        : null}
    </ScrollView>
  );
}

const Drawer = createDrawerNavigator();
const MyTheme = {
  ...DefaultTheme,
  colors: {
    ...DefaultTheme.colors,
    background: '#171717',
    color: '#fdfbf9',
  },
};

function MyDrawer() {
  return (
    <Drawer.Navigator
      screenOptions={{
        drawerStyle: {
          backgroundColor: '#0c1559',
          width: 250,
          fontFamily: 'Teko_700Bold',
        },
        headerStyle: {
          backgroundColor: '#0c1559',
          color: '#fdfbf9',
          elevation: 0,
          shadowOpacity: 0,
        },
        drawerLabelStyle: {
          color: '#fdfbf9',
          fontFamily: 'Teko_700Bold',
          fontSize: 18,
        },
      }}>
      <Drawer.Screen
        name="Conversations"
        component={Conversations}
        options={{
          headerStyle: {
            backgroundColor: '#0c1559',
            color: '#fdfbf9',
            elevation: 0,
            shadowOpacity: 0,
          },
          headerTintColor: '#fff',
          headerTitleStyle: {
            fontFamily: 'Teko_700Bold',
            fontSize: 18,
          },
        }}
      />
      <Drawer.Screen
        name="Search"
        component={Search}
        options={{
          headerStyle: {
            backgroundColor: '#0c1559',
            color: '#fdfbf9',
            elevation: 0,
            shadowOpacity: 0,
          },
          headerTintColor: '#fff',
          headerTitleStyle: {
            fontFamily: 'Teko_700Bold',
            fontSize: 18,
          },
        }}
      />
    </Drawer.Navigator>
  );
}

const styles = StyleSheet.create({
  chats: {
    backgroundColor: '#171717',
    width: '100%',
    height: '100%',
    padding: 10,
  },

  userConvos: {
    display: 'flex',
    flexDirection: 'row',
    color: '#FDFBF9',
    fontSize: 18,
    borderColor: 'none',
    borderWidth: 0,
    borderBottomColor: '#0C1559',
    borderBottomWidth: 2,
    padding: 10,
    borderRadius: 10,
    margin: 5,
    backgroundColor: 'black',
    opacity: '.8',
  },

  convoImage: {
    width: 60,
    height: 60,
    borderRadius: '50%',
  },

  titleText: {
    paddingLeft: 10,
    fontSize: 23,
    letteSpacing: '.03rem',
    color: '#fdfbf9',
    fontFamily: 'Teko_700Bold',
    margin: 10,
    marginTop: 20,
  },

  userSearch: {
    margin: 10,
    width: '100%',
  },

  userlist: {
    display: 'flex',
    flexDirection: 'row',
    borderRadius: 10,
    backgroundColor: ' rgba(19, 19, 19, 0.8)',
    padding: 5,
    fontFamily: 'Teko_700Bold',
    letterSpacing: '.03rem',
    width: '100%',
  },

  userPic: {
    width: 60,
    height: 60,
    borderRadius: '50%',
  },

  userName: {
    fontSize: 18,
    color: '#fdfbf9',
    fontFamily: 'Teko_700Bold',
    marginLeft: 5,
    marginTop: 10,
  },

  messageMe: {
    backgroundColor: '#0C1559',
    color: '#fdfbf9',
    fontSize: 16,
    fontFamily: 'Teko_700Bold',
    letterSpacing: '.03rem',
    position: 'absolute',
    right: 0,
    marginLeft: 30,
    display: 'block',
  },

  userSearched: {
    display: 'flex',
    flexDirection: 'row',
    width: '100%',
  },
  message: {
    fontSize: 21,
    textAlign: 'center',
    margin: '1rem auto',
    marginTop: 250,
    color: '#a9a9b0',
    fontFamily: 'Teko_700Bold',
  },
  deleteBox: {
    backgroundColor: '#B2022F',
    justifyContent: 'center',
    alignItems: 'center',
    width: 50,
    height: 85,
  },
});

export default function App() {
  return <MyDrawer />;
}
